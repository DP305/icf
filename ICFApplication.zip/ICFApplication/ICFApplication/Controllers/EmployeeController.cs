﻿using ICFApplication.BussinessLogic.IRepositoryServices;
using ICFApplication.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeServices _employeeServices;

        public EmployeeController(IEmployeeServices employeeServices)
        {
            this._employeeServices = employeeServices;
        }




        [HttpGet]
        [Route("GetEmployee")]
        public async Task<IActionResult> GetEmployee()
        {
            Result<IEnumerable<EmployeeEducationRelationship>> result = null;
            try
            {
                var data = await _employeeServices.GetEmployee();
                if (data != null)
                {
                    result = data;
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                result = new Result<IEnumerable<EmployeeEducationRelationship>>()
                {
                    status = false,
                    DeveloperMsg = ex.Message,
                    Data = null
                };
                return Ok(result);
            }

        }



        [HttpGet]
        [Route("GetEmployee/{EmpId}")]
        public async Task<IActionResult> GetEmployee(long EmpId)
        {
            Result<EmployeeEducationRelationship> result = null;
            try
            {
                var data = await _employeeServices.GetEmployee(EmpId);
                if (data != null)
                {
                    result = data;
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                result = new Result<EmployeeEducationRelationship>()
                {
                    status = false,
                    DeveloperMsg = ex.Message,
                    Data = null
                };
                return Ok(result);
            }

        }




        [HttpGet]
        [Route("CreateEmployee")]
        public async Task<IActionResult> CreateEmployee(EmployeeEducationRelationship EmployeeEducationRelationship)
        {
            Result<EmployeeEducationRelationship> result = null;
            try
            {
                var data = await _employeeServices.CreateEmployee(EmployeeEducationRelationship);
                if (data != null)
                {
                    result = data;
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                result = new Result<EmployeeEducationRelationship>()
                {
                    status = false,
                    DeveloperMsg = ex.Message,
                    Data = null
                };
                return Ok(result);
            }

        }






    }
}
