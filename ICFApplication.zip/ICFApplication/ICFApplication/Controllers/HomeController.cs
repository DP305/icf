﻿using ICFApplication.APIServices.IAPIServices;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEmployeeAPIServices _employeeAPI;

        public IMasterDataAPIServices _MasterDataAPIServices { get; }

        public HomeController(IEmployeeAPIServices employeeAPI,IMasterDataAPIServices masterDataAPIServices)
        {
            this._employeeAPI = employeeAPI;
            _MasterDataAPIServices = masterDataAPIServices;
        }



        public async Task<IActionResult> Index()
        {
            try
            {
                var APIResponse = await _employeeAPI.GetEmployee();
                var Newdata = APIResponse.Data;
                return View(Newdata);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }



        public async Task<IActionResult> Create()
        {
            try
            {
                var APIResponse = await _employeeAPI.GetEmployee();
                var Newdata = APIResponse.Data;
                return View();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }


        public async Task<IActionResult> GetDepartment()
        {
            try
            {
                var APIResponse = await _MasterDataAPIServices.GetDepartment();
                var Newdata = APIResponse.Data;
                return Json(Newdata);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }
        public async Task<IActionResult> GetDesignation()
        {
            try
            {
                var APIResponse = await _MasterDataAPIServices.GetDesignation();
                var Newdata = APIResponse.Data;
                return View(Newdata);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }






    }
}
