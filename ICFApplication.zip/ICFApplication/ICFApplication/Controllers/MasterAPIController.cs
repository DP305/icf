﻿using ICFApplication.BussinessLogic.IRepositoryServices;
using ICFApplication.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterAPIController : ControllerBase
    {
        private readonly IMasterDataServices masterDataServices;

        public MasterAPIController(IMasterDataServices masterDataServices )
        {
            this.masterDataServices = masterDataServices;
        }



        [HttpGet]
        [Route("GetDepartment")]
        public async Task<IActionResult> GetDepartment()
        {
            Result<IEnumerable<Department>> result = null;
            try
            {
                var data = await masterDataServices.GetDepartment();
                if (data != null)
                {
                    result = data;
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                result = new Result<IEnumerable<Department>>()
                {
                    status = false,
                    DeveloperMsg = ex.Message,
                    Data = null
                };
                return Ok(result);
            }

        }



        [HttpGet]
        [Route("GetDesignation")]
        public async Task<IActionResult> GetDesignation()
        {
            Result<IEnumerable<Designation>> result = null;
            try
            {
                var data = await masterDataServices.GetDesignation();
                if (data != null)
                {
                    result = data;
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                result = new Result<IEnumerable<Designation>>()
                {
                    status = false,
                    DeveloperMsg = ex.Message,
                    Data = null
                };
                return Ok(result);
            }

        }




    }
}
