﻿using System;
using System.Collections.Generic;

namespace ICFApplication.Models
{
    public partial class EducationDetails
    {
        public EducationDetails()
        {
            EmployeeEducationRelationship = new HashSet<EmployeeEducationRelationship>();
        }

        public long Id { get; set; }
        public string Degree { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Institution { get; set; }
        public string Address { get; set; }
        public double? Percentage { get; set; }
        public byte? Status { get; set; }

        public virtual ICollection<EmployeeEducationRelationship> EmployeeEducationRelationship { get; set; }
    }
}
