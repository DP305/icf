﻿using System;
using System.Collections.Generic;

namespace ICFApplication.Models
{
    public partial class Employee
    {
        public Employee()
        {
            EmployeeEducationRelationship = new HashSet<EmployeeEducationRelationship>();
        }

        public long Id { get; set; }
        public long? EmploymentId { get; set; }
        public long? DepartmentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public long? DesignationId { get; set; }
        public DateTime? Dob { get; set; }
        public long? ReportingManager { get; set; }
        public string Gender { get; set; }
        public string BloodGroup { get; set; }
        public string Address { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public byte? Status { get; set; }
        public DateTime? CreationDate { get; set; }

        public virtual Department Department { get; set; }
        public virtual Designation Designation { get; set; }
        public virtual ICollection<EmployeeEducationRelationship> EmployeeEducationRelationship { get; set; }

    }
}
