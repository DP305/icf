﻿using System;
using System.Collections.Generic;

namespace ICFApplication.Models
{
    public partial class Department
    {
        public Department()
        {
            Employee = new HashSet<Employee>();
        }

        public long Id { get; set; }
        public string DepartmentName { get; set; }
        public byte? Status { get; set; }

        public virtual ICollection<Employee> Employee { get; set; }
    }
}
