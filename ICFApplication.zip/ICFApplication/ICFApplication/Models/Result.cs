﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.Models
{

    public class Result<T>
    {
        public bool status { get; set; }
        public string DeveloperMsg { get; set; }
        public T Data { get; set; }
        public ErrorViewModel  error { get; set; }
    }

}
