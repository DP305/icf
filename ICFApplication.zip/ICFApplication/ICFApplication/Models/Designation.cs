﻿using System;
using System.Collections.Generic;

namespace ICFApplication.Models
{
    public partial class Designation
    {
        public Designation()
        {
            Employee = new HashSet<Employee>();
        }

        public long Id { get; set; }
        public string DesignationName { get; set; }
        public byte? Status { get; set; }

        public virtual ICollection<Employee> Employee { get; set; }
    }
}
