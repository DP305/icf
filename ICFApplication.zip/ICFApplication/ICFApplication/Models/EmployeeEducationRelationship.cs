﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace ICFApplication.Models
{
    public partial class EmployeeEducationRelationship
    {
        public long Id { get; set; }
        public long? EmployeeId { get; set; }
        public long? EducationDetailsId { get; set; }
       
        [NotMapped]
        public virtual EducationDetails EducationDetails { get; set; }
        [NotMapped]
        public virtual Employee Employee { get; set; }
    }
}
