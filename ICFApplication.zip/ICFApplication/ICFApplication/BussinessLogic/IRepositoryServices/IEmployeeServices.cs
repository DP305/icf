﻿using ICFApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.BussinessLogic.IRepositoryServices
{
    public interface IEmployeeServices
    {

        public Task<Result<IEnumerable<EmployeeEducationRelationship>>> GetEmployee();
        public Task<Result<EmployeeEducationRelationship>> GetEmployee(long EmployeeId);
        public Task<Result<EmployeeEducationRelationship>> CreateEmployee(EmployeeEducationRelationship EmployeeEducationRelationship);
        public Task<Result<EmployeeEducationRelationship>> UpdateEmployee(EmployeeEducationRelationship EmployeeEducationRelationship);



    }


}
