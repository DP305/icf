﻿using ICFApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.BussinessLogic.IRepositoryServices
{
    public interface IMasterDataServices
    {
        Task<Result<IEnumerable<Department>>> GetDepartment();
        Task<Result<IEnumerable<Designation>>> GetDesignation();


    }
}
