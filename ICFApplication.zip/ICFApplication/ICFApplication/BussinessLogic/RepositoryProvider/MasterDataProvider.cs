﻿using ICFApplication.BussinessLogic.IRepositoryServices;
using ICFApplication.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.BussinessLogic.RepositoryProvider
{
    public class MasterDataProvider : IMasterDataServices
    {
        private readonly ICFDBContext _iCFDB;

        public MasterDataProvider(ICFDBContext iCFDB)
        {
            this._iCFDB = iCFDB;
        }

        public async Task<Result<IEnumerable<Department>>> GetDepartment()
        {
            Result<IEnumerable<Department>> result = null;
            try
            {
                var data = await _iCFDB.Department.ToListAsync();
                if (data != null)
                {
                    result = new Result<IEnumerable<Department>>()
                    {
                        status = true,
                        DeveloperMsg = "",
                        Data = data,
                    };
                }
                else
                {
                    result = new Result<IEnumerable<Department>>()
                    {
                        status = true,
                        DeveloperMsg = "No reacord ",
                        Data = data,
                    };
                }
                return result;
            }
            catch (Exception ex)
            {
                result = new Result<IEnumerable<Department>>()
                {
                    status = true,
                    DeveloperMsg = ex.Message,
                    Data = null,
                };
                return result;
            }
        }

        public async Task<Result<IEnumerable<Designation>>> GetDesignation()
        {
            Result<IEnumerable<Designation>> result = null;
            try
            {
                var data = await _iCFDB.Designation.ToListAsync();
                if (data != null)
                {
                    result = new Result<IEnumerable<Designation>>()
                    {
                        status = true,
                        DeveloperMsg = "",
                        Data = data,
                    };
                }
                else
                {
                    result = new Result<IEnumerable<Designation>>()
                    {
                        status = true,
                        DeveloperMsg = "No reacord ",
                        Data = data,
                    };
                }
                return result;
            }
            catch (Exception)
            {
                result = new Result<IEnumerable<Designation>>()
                {
                    status = true,
                    DeveloperMsg = "",
                    Data = null,
                };
                return result;
            }
        }


    }
}
