﻿using ICFApplication.BussinessLogic.IRepositoryServices;
using ICFApplication.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.BussinessLogic.RepositoryProvider
{
    public class EmployeeProvider : IEmployeeServices
    {
        private readonly ICFDBContext _iCFDB;

        public EmployeeProvider(ICFDBContext iCFDB)
        {
            this._iCFDB = iCFDB;
        }


        public async Task<Result<EmployeeEducationRelationship>> CreateEmployee(EmployeeEducationRelationship EmployeeEducationRelationship)
        {
            Result<EmployeeEducationRelationship> result = null;
            try
            {
                if (EmployeeEducationRelationship.Employee != null)
                {
                    Employee model = new Employee()
                    {
                        FirstName = EmployeeEducationRelationship.Employee.FirstName,
                        LastName = EmployeeEducationRelationship.Employee.LastName,
                        DesignationId = EmployeeEducationRelationship.Employee.DesignationId,
                        Dob = EmployeeEducationRelationship.Employee.Dob,
                        ReportingManager = EmployeeEducationRelationship.Employee.ReportingManager,
                        Gender = EmployeeEducationRelationship.Employee.Gender,
                        BloodGroup = EmployeeEducationRelationship.Employee.BloodGroup,
                        Address = EmployeeEducationRelationship.Employee.Address,
                        StartDate = EmployeeEducationRelationship.Employee.StartDate,
                        Status = 1,
                        CreationDate = DateTime.Now
                    };
                    var NewEmployee = await _iCFDB.Employee.AddAsync(model);
                    await _iCFDB.SaveChangesAsync();
                    if (NewEmployee != null)
                    {
                        EducationDetails modelEducation = new EducationDetails()
                        {
                            Degree = EmployeeEducationRelationship.EducationDetails.Degree,
                            StartDate = EmployeeEducationRelationship.EducationDetails.StartDate,
                            EndDate = EmployeeEducationRelationship.EducationDetails.EndDate,
                            Institution = EmployeeEducationRelationship.EducationDetails.Institution,

                            Address = EmployeeEducationRelationship.EducationDetails.Address,
                            Percentage = EmployeeEducationRelationship.EducationDetails.Percentage,
                            Status = 1,
                        };
                        var NewEducationEmployee = await _iCFDB.EducationDetails.AddAsync(modelEducation);
                        await _iCFDB.SaveChangesAsync();
                        if (NewEducationEmployee != null)
                        {
                            EmployeeEducationRelationship obj = new EmployeeEducationRelationship()
                            {
                                EducationDetailsId = NewEducationEmployee.Entity.Id,
                                EmployeeId = NewEmployee.Entity.Id
                            };
                            var NewRelationNew = await _iCFDB.EmployeeEducationRelationship.AddAsync(obj);
                            await _iCFDB.SaveChangesAsync();
                            result = new Result<EmployeeEducationRelationship>()
                            {
                                status = false,
                                DeveloperMsg = "No record Recieved ",
                                Data = NewRelationNew.Entity
                            };
                        }
                    }
                }
                else
                {
                    result = new Result<EmployeeEducationRelationship>()
                    {
                        status = false,
                        DeveloperMsg = "No record Recieved ",
                        Data = null,

                    };

                }
                return result;
            }
            catch (Exception ex)
            {
                result = new Result<EmployeeEducationRelationship>()
                {
                    status = false,
                    DeveloperMsg = ex.Message,
                    Data = null,
                    error = new ErrorViewModel()
                    {
                        RequestId = ex.StackTrace,
                        Message = ex.Source
                    }
                };
                return result;
            }
        }

        public async Task<Result<IEnumerable<EmployeeEducationRelationship>>> GetEmployee()
        {
            Result<IEnumerable<EmployeeEducationRelationship>> result = null;
            try
            {
                //var data = await _iCFDB.EmployeeEducationRelationship.ToListAsync();
                var data = await _iCFDB.EmployeeEducationRelationship.Include(e => e.Employee).Include(e => e.EducationDetails).ToListAsync();
                if (data != null)
                {
                    result = new Result<IEnumerable<EmployeeEducationRelationship>>()
                    {
                        status = true,
                        DeveloperMsg = "",
                        Data = data,
                    };
                }
                else
                {
                    result = new Result<IEnumerable<EmployeeEducationRelationship>>()
                    {
                        status = true,
                        DeveloperMsg = "No reacord ",
                        Data = data,
                    };
                }
                return result;
            }
            catch (Exception ex)
            {
                result = new Result<IEnumerable<EmployeeEducationRelationship>>()
                {
                    status = true,
                    DeveloperMsg = ex.Message,
                    Data = null,
                };
                return result;
            }
        }

        public async Task<Result<EmployeeEducationRelationship>> GetEmployee(long EmployeeId)
        {
            Result<EmployeeEducationRelationship> result = null;
            try
            {
                var data = await _iCFDB.EmployeeEducationRelationship.Include(e => e.Employee).Include(e => e.EducationDetails).FirstOrDefaultAsync(e => e.EmployeeId == EmployeeId);
                if (data != null)
                {
                    result = new Result<EmployeeEducationRelationship>()
                    {
                        status = true,
                        DeveloperMsg = "",
                        Data = data,
                    };
                }
                else
                {
                    result = new Result<EmployeeEducationRelationship>()
                    {
                        status = true,
                        DeveloperMsg = "No reacord ",
                        Data = data,
                    };
                }
                return result;

            }
            catch (Exception ex)
            {
                result = new Result<EmployeeEducationRelationship>()
                {
                    status = false,
                    DeveloperMsg = ex.Message,
                    Data = null,
                };
                return result;
            }
        }

        public async Task<Result<EmployeeEducationRelationship>> UpdateEmployee(EmployeeEducationRelationship EmployeeEducationRelationship)
        {
            Result<EmployeeEducationRelationship> result = null;
            try
            {
                if (EmployeeEducationRelationship.Employee != null)
                {
                    Employee model = new Employee()
                    {
                        FirstName = EmployeeEducationRelationship.Employee.FirstName,
                        LastName = EmployeeEducationRelationship.Employee.LastName,
                        DesignationId = EmployeeEducationRelationship.Employee.DesignationId,
                        Dob = EmployeeEducationRelationship.Employee.Dob,
                        ReportingManager = EmployeeEducationRelationship.Employee.ReportingManager,
                        Gender = EmployeeEducationRelationship.Employee.Gender,
                        BloodGroup = EmployeeEducationRelationship.Employee.BloodGroup,
                        Address = EmployeeEducationRelationship.Employee.Address,
                        StartDate = EmployeeEducationRelationship.Employee.StartDate,
                        Status = 1,
                        CreationDate = DateTime.Now
                    };
                    var NewEmployee = await _iCFDB.Employee.AddAsync(model);
                    await _iCFDB.SaveChangesAsync();
                    if (NewEmployee != null)
                    {
                        EducationDetails modelEducation = new EducationDetails()
                        {
                            Degree = EmployeeEducationRelationship.EducationDetails.Degree,
                            StartDate = EmployeeEducationRelationship.EducationDetails.StartDate,
                            EndDate = EmployeeEducationRelationship.EducationDetails.EndDate,
                            Institution = EmployeeEducationRelationship.EducationDetails.Institution,

                            Address = EmployeeEducationRelationship.EducationDetails.Address,
                            Percentage = EmployeeEducationRelationship.EducationDetails.Percentage,
                            Status = 1,
                        };
                        var NewEducationEmployee = await _iCFDB.EducationDetails.AddAsync(modelEducation);
                        await _iCFDB.SaveChangesAsync();
                        if (NewEducationEmployee != null)
                        {
                            EmployeeEducationRelationship obj = new EmployeeEducationRelationship()
                            {
                                EducationDetailsId = NewEducationEmployee.Entity.Id,
                                EmployeeId = NewEmployee.Entity.Id
                            };
                            var NewRelationNew = await _iCFDB.EmployeeEducationRelationship.AddAsync(obj);
                            await _iCFDB.SaveChangesAsync();
                            result = new Result<EmployeeEducationRelationship>()
                            {
                                status = false,
                                DeveloperMsg = "No record Recieved ",
                                Data = NewRelationNew.Entity
                            };
                        }
                    }
                }
                else
                {
                    result = new Result<EmployeeEducationRelationship>()
                    {
                        status = false,
                        DeveloperMsg = "No record Recieved ",
                        Data = null,

                    };

                }
                return result;
            }
            catch (Exception ex)
            {
                result = new Result<EmployeeEducationRelationship>()
                {
                    status = false,
                    DeveloperMsg = ex.Message,
                    Data = null,
                    error = new ErrorViewModel()
                    {
                        RequestId = ex.StackTrace,
                        Message = ex.Source
                    }
                };
                return result;
            }
        }
    }
}
