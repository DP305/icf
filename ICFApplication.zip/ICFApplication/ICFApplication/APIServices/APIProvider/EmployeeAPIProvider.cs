﻿using ICFApplication.APIServices.IAPIServices;
using ICFApplication.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ICFApplication.APIServices.APIProvider
{
    public class EmployeeAPIProvider : IEmployeeAPIServices
    {

        private const string BaseUrl = "https://localhost:44343/";
        private readonly HttpClient _client;
        public EmployeeAPIProvider(HttpClient _client)
        {
            this._client = _client;
        }



        public async Task<Result<EducationDetails>> CreateEmployee(EducationDetails educationDetails)
        {
            Result<EducationDetails> result = null;
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(educationDetails), Encoding.UTF8, "application/json");

                using (var response = await httpClient.PostAsync(BaseUrl + "api/Employee/CreateEmployee", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<Result<EducationDetails>>(apiResponse);
                }
            }
            return result;
        }

        public async Task<Result<IEnumerable<EmployeeEducationRelationship>>> GetEmployee()
        {
            var httpResponse = await _client.GetAsync(BaseUrl + "api/Employee/GetEmployee");

            if (!httpResponse.IsSuccessStatusCode)
            {
                throw new Exception("Cannot retrieve tasks");
            }
            var content = await httpResponse.Content.ReadAsStringAsync();
            var tasks = JsonConvert.DeserializeObject<Result<IEnumerable<EmployeeEducationRelationship>>>(content);
            return tasks;
        }

        public async Task<Result<EmployeeEducationRelationship>> GetEmployee(int EmployeeId)
        {
            Result<EmployeeEducationRelationship> result = null;
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(BaseUrl + "api/Employee/GetEmployee/" + EmployeeId))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<Result<EmployeeEducationRelationship>>(apiResponse);
                }
            }
            return result;
        }

        public Task<Result<EducationDetails>> UpdateEmployee(EducationDetails educationDetails)
        {
            throw new NotImplementedException();
        }
    }
}
