﻿using ICFApplication.APIServices.IAPIServices;
using ICFApplication.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace ICFApplication.APIServices.APIProvider
{
    public class MasterDataAPIProvider : IMasterDataAPIServices
    {

        private const string BaseUrl = "https://localhost:44343/";
        private readonly HttpClient _client;

        public MasterDataAPIProvider(HttpClient client)
        {
            this._client = client;
        }


        public async Task<Result<IEnumerable<Department>>> GetDepartment()
        {
            var httpResponse = await _client.GetAsync(BaseUrl + "api/MasterAPI/GetDepartment");

            if (!httpResponse.IsSuccessStatusCode)
            {
                throw new Exception("Cannot retrieve tasks");
            }
            var content = await httpResponse.Content.ReadAsStringAsync();
            var tasks = JsonConvert.DeserializeObject<Result<IEnumerable<Department>>>(content);
            return tasks;
        }

        public async Task<Result<IEnumerable<Designation>>> GetDesignation()
        {
            var httpResponse = await _client.GetAsync(BaseUrl + "api/MasterAPI/GetDesignation");

            if (!httpResponse.IsSuccessStatusCode)
            {
                throw new Exception("Cannot retrieve tasks");
            }
            var content = await httpResponse.Content.ReadAsStringAsync();
            var tasks = JsonConvert.DeserializeObject<Result<IEnumerable<Designation>>>(content);
            return tasks;
        }
   
    
    
    
    }
}
