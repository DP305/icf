﻿using ICFApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.APIServices.IAPIServices
{
  public    interface IEmployeeAPIServices
    {
        public Task<Result<IEnumerable<EmployeeEducationRelationship>>> GetEmployee();
        public Task<Result<EmployeeEducationRelationship>> GetEmployee(int EmployeeId);
        public Task<Result<EducationDetails>> CreateEmployee(EducationDetails educationDetails);
        public Task<Result<EducationDetails>> UpdateEmployee(EducationDetails educationDetails);

    }
}
