﻿using ICFApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICFApplication.APIServices.IAPIServices
{
    public interface IMasterDataAPIServices
    {
        Task<Result<IEnumerable<Department>>> GetDepartment();
        Task<Result<IEnumerable<Designation>>> GetDesignation();

    }
}
